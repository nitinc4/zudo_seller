const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Seller = require('../models/Seller');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Driver = require('../models/Driver');
const { protect } = require('../middleware/auth');

// @route   POST /api/sellers/login
// @desc    Seller Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  console.log(`Login attempt for: ${email} (Sellers Collection)`);
  
  try {
    // Search in the Sellers collection
    const user = await Seller.findOne({ 
      email: { $regex: new RegExp(`^${email}$`, 'i') }
    });

    if (!user) {
      console.log(`Login failed: No account found in Sellers collection with email ${email}`);
      return res.status(401).json({ message: 'No seller account found with this email' });
    }

    const isMatch = await user.comparePassword(password);
    if (isMatch) {
      const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
      console.log(`Login successful for: ${email}`);

      // Check if profile is complete (handle both b2b and seller field names)
      const businessName = user.businessName || user.storeName;
      const businessAddress = user.businessAddress || user.billingAddress;
      const isProfileComplete = !!(businessName && businessAddress && user.phone);

      res.json({
        token,
        _id: user._id,
        name: user.name,
        email: user.email,
        isProfileComplete,
        businessName: businessName,
        phone: user.phone
      });
    } else {
      console.log(`Login failed: Incorrect password for ${email}`);
      res.status(401).json({ message: 'Invalid password' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/sellers/me
// @desc    Get current seller profile
router.get('/me', protect, async (req, res) => {
  try {
    const user = await Seller.findById(req.user._id).select('-password');
    if (!user) return res.status(404).json({ message: 'Seller not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   PUT /api/sellers/profile
// @desc    Update seller profile
router.put('/profile', protect, async (req, res) => {
  try {
    const user = await Seller.findById(req.user._id);
    if (!user) return res.status(404).json({ message: 'Seller not found' });

    // Update fields (handle multiple naming conventions)
    user.name = req.body.name || user.name;
    user.phone = req.body.phone || user.phone;
    user.businessName = req.body.businessName || req.body.storeName || user.businessName;
    user.businessAddress = req.body.businessAddress || req.body.billingAddress || user.businessAddress;
    user.gstNumber = req.body.gstNumber || user.gstNumber;
    user.panNumber = req.body.panNumber || user.panNumber;
    
    // Support legacy field names in the database object itself if they exist
    if (user.storeName) user.storeName = req.body.storeName || req.body.businessName || user.storeName;
    if (user.billingAddress) user.billingAddress = req.body.billingAddress || req.body.businessAddress || user.billingAddress;

    // Pickup Location handling
    if (req.body.pickupLocation) {
      user.pickupLocation = req.body.pickupLocation;
    }

    // Mark profile as complete
    user.isProfileComplete = true;

    const updatedUser = await user.save();
    console.log(`Profile updated successfully for: ${user.email}`);
    res.json(updatedUser);
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ 
      message: 'Failed to update profile', 
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// @route   GET /api/sellers/products
// @desc    Get seller's products
router.get('/products', protect, async (req, res) => {
  try {
    const products = await Product.find({
      $or: [
        { sellerId: req.user._id.toString() },
        { seller: req.user._id }
      ]
    }).populate('categoryId subCategoryId');
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/sellers/orders
// @desc    Get seller's orders
router.get('/orders', protect, async (req, res) => {
  try {
    const sellerId = req.user._id;

    // 1. Find all products belonging to this seller
    const sellerProducts = await Product.find({
      $or: [
        { sellerId: sellerId.toString() },
        { seller: sellerId }
      ]
    }).select('_id');

    if (!sellerProducts || sellerProducts.length === 0) {
      return res.json([]);
    }

    const productIds = sellerProducts.map(p => p._id);

    // 2. Find orders that contain ANY of these product IDs
    // We check both productId and product._id for compatibility
    const orders = await Order.find({
      $or: [
        { 'items.productId': { $in: productIds } },
        { 'items.product._id': { $in: productIds } }
      ]
    })
      .populate('userId', 'name email phone') // Populate customer info
      .populate('deliveryBoyId', 'name phone email') // Populate driver info
      .sort({ createdAt: -1 });

    res.json(orders);
  } catch (error) {
    console.error('Seller orders fetch error:', error);
    res.status(500).json({ message: error.message });
  }
});

// @route   GET /api/sellers/pickups
// @desc    Get seller's pickups
router.get('/pickups', protect, async (req, res) => {
  try {
    const sellerId = req.user._id;

    // 1. Find all products belonging to this seller
    const sellerProducts = await Product.find({
      $or: [
        { sellerId: sellerId.toString() },
        { seller: sellerId }
      ]
    }).select('_id');
    const productIds = sellerProducts.map(p => p._id);

    // 2. Find orders that are ready for pickup (Packed), already Picked Up, or Pending
    const orders = await Order.find({
      $and: [
        {
          $or: [
            { 'items.productId': { $in: productIds } },
            { 'items.product._id': { $in: productIds } }
          ]
        },
        { orderStatus: { $in: ['Pending', 'Packed', 'Picked Up', 'Shipped', 'Delivered'] } }
      ]
    })
      .populate('userId', 'name email phone')
      .populate('deliveryBoyId', 'name phone')
      .populate('driverId', 'name phone')
      .sort({ updatedAt: -1 });

    // Format for frontend and generate code if missing
    const pickups = await Promise.all(orders.map(async (order) => {
      try {
        if (!order.pickupCode) {
          order.pickupCode = Math.floor(1000 + Math.random() * 9000).toString();
          await order.save();
        }

        return {
          _id: order._id,
          pickupId: order.orderId || order._id.toString().slice(-6).toUpperCase(),
          status: order.orderStatus,
          scheduledDate: order.updatedAt,
          timeSlot: 'Standard', 
          address: order.shippingAddress?.address ? `${order.shippingAddress.address}, ${order.shippingAddress.city || ''}` : 'No address provided',
          itemCount: order.items?.length || 0,
          items: order.items || [],
          driver: order.driverId || order.deliveryBoyId,
          customer: order.userId,
          pickupCode: order.pickupCode,
          totalAmount: order.totalAmount || 0
        };
      } catch (err) {
        console.error(`Error processing order ${order._id}:`, err);
        return null;
      }
    }));

    res.json(pickups.filter(p => p !== null));
  } catch (error) {
    console.error('Pickups fetch error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.get('/stats', protect, async (req, res) => {
  try {
    const sellerId = req.user._id;

    // Total Products
    const totalProducts = await Product.countDocuments({
      $or: [
        { sellerId: sellerId.toString() },
        { seller: sellerId }
      ]
    });

    // Seller Products IDs
    const sellerProducts = await Product.find({
      $or: [
        { sellerId: sellerId.toString() },
        { seller: sellerId }
      ]
    }).select('_id');
    const productIds = sellerProducts.map(p => p._id);

    // Orders stats
    const orders = await Order.find({
      'items.productId': { $in: productIds }
    });

    const activeOrders = orders.filter(o => ['Pending', 'Processing', 'Shipped'].includes(o.orderStatus)).length;
    const totalSales = orders
      .filter(o => o.orderStatus !== 'Cancelled')
      .reduce((acc, curr) => {
        // Only sum items belonging to THIS seller
        const sellerItems = (curr.items || []).filter(item => 
          item.productId && productIds.some(pid => pid.toString() === item.productId.toString())
        );
        const sellerTotal = sellerItems.reduce((s, i) => s + (i.price * i.quantity), 0);
        return acc + sellerTotal;
      }, 0);

    res.json({
      totalProducts,
      activeOrders,
      totalSales,
      totalOrders: orders.length
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
