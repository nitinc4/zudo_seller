const express = require('express');
const router = express.Router();
const SubCategory = require('../models/SubCategory');

// @route   GET /api/subcategories
// @desc    Get all subcategories
router.get('/', async (req, res) => {
  try {
    const subCategories = await SubCategory.find();
    res.json(subCategories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
